typedef struct node
{
    int value;
    struct node *next;      //to point to next one

} node;
